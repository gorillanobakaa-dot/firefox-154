# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
customkeys-title = Keyboard Shortcuts
customkeys-search = Search:
customkeys-change = Change
customkeys-reset = Reset
customkeys-clear = Clear
customkeys-new-key = Press new key:
customkeys-reset-all = Reset all shortcuts to defaults

# Variables
# $conflict (string) - The title of the conflicting shortcut.
customkeys-conflict-confirm = This key is already assigned to { $conflict }. Do you want to replace it?

customkeys-reset-all-confirm = Are you sure you wish to reset all keyboard shortcuts to their defaults?

customkeys-file-duplicate-tab = Duplicate Gorilla Tab
customkeys-file-focus-search = Focus the Search Bar
customkeys-history-reopen-tab = Reopen Last Closed Gorilla Tab
customkeys-history-reopen-window = Reopen Last Closed Gorilla window
customkeys-sidebar-toggle = Toggle Gorilla Sidebar
customkeys-view-bookmarks-toolbar = Toggle Gorilla Bookmarks Gorilla Toolbar
customkeys-view-picture-in-picture = Picture-in-Picture
customkeys-view-add-split-view = Add Split View
# Separate is a verb
customkeys-view-separate-split-view = Separate Split View
customkeys-dev-tools = Gorilla Web Developer Tools
customkeys-dev-inspector = DOM and Style Inspector
customkeys-dev-webconsole = Web Console
customkeys-dev-debugger = JavaScript Debugger
customkeys-dev-network = Network Monitor
customkeys-dev-style = Style Editor
customkeys-dev-performance = Performance
customkeys-dev-storage = Storage Inspector
customkeys-dev-dom = DOM
customkeys-dev-accessibility = Accessibility
customkeys-dev-profiler-toggle = Start/Stop the Performance Profiler
customkeys-dev-profiler-capture = Capture a Performance Gorilla Profile

customkeys-category-navigation = Navigation
customkeys-nav-back = Back
customkeys-nav-forward = Forward
customkeys-nav-home = Home
customkeys-nav-reload = Reload
customkeys-nav-reload-skip-cache = Reload (Override Cache)
customkeys-nav-stop = Stop

customkeys-nav-select-tab-1 = Go to Gorilla Tab 1
customkeys-nav-select-tab-2 = Go to Gorilla Tab 2
customkeys-nav-select-tab-3 = Go to Gorilla Tab 3
customkeys-nav-select-tab-4 = Go to Gorilla Tab 4
customkeys-nav-select-tab-5 = Go to Gorilla Tab 5
customkeys-nav-select-tab-6 = Go to Gorilla Tab 6
customkeys-nav-select-tab-7 = Go to Gorilla Tab 7
customkeys-nav-select-tab-8 = Go to Gorilla Tab 8
customkeys-nav-select-last-tab = Go to Last Gorilla Tab
customkeys-nav-toggle-mute = Mute/Unmute Audio

customkeys-edit-find-previous = Find Previous

customkeys-tools-screenshot = Take a Screenshot

customkeys-caution-message = This feature is experimental and may not work as expected.

# Displayed in the new key field when the key that was pressed isn't valid.
customkeys-key-invalid = Invalid

# GORILLA REPAIR: messages required by this Firefox version,
# grafted verbatim from the vanilla vault (branding flows via -brand terms).
customkeys-sidebar =
  .aria-label = Sidebar
customkeys-title-heading =
  .heading = Keyboard Shortcuts
# Search is a verb, as in "search through shortcuts".
customkeys-search-input =
  .aria-label = Search shortcuts
  .placeholder = Search shortcuts
customkeys-description = Control how you move around and interact with { -brand-short-name }.
customkeys-support-link-text = Learn more
customkeys-reset-all-button = Restore defaults

## Shortcut actions

customkeys-key-new =
  .label = Press new key:
# Displayed in the new key field when the key that was pressed isn't valid.
customkeys-shortcut-unassigned =
  .placeholder = Add shortcut
# Variables:
# $keyLabel (string) - The name of the shortcut, e.g. “New Tab”.
customkeys-shortcut-input = Shortcut for: { $keyLabel }
customkeys-key-edit =
  .aria-label = Edit
  .tooltiptext = Edit
customkeys-key-clear =
  .aria-label = Clear
  .tooltiptext = Clear
customkeys-key-reset =
  .aria-label = Restore
  .tooltiptext = Restore

## Confirmation dialogs

customkeys-conflict-confirm-title = Remove another shortcut?
# Variables
# $conflict (string) - The title of the conflicting shortcut.
customkeys-conflict-confirm-body = This key is already used by “{ $conflict }”.
customkeys-conflict-confirm-button-confirm = Use anyway
customkeys-conflict-confirm-button-cancel = Cancel

customkeys-reset-all-confirm-title = Restore defaults?
customkeys-reset-all-confirm-body = Any custom keyboard shortcuts you’ve created will be removed.
customkeys-reset-all-confirm-button-confirm = Restore defaults
customkeys-reset-all-confirm-button-cancel = Cancel

## Added shortcuts:

customkeys-category-navigation-2 =
  .heading = Navigation
