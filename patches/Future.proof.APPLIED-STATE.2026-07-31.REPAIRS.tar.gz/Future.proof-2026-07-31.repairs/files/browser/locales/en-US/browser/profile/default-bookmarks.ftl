# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
# This file intentionally uses hard-coded brand names instead of Fluent terms.
# This approach minimizes issues across multiple release channels and rebranded
# versions.
default-bookmarks-title = Gorilla Bookmarks
default-bookmarks-heading = Gorilla Bookmarks

# Firefox links folder name
default-bookmarks-firefox-heading = Gorilla Unleashed

# link title for https://www.mozilla.org/firefox/help/
default-bookmarks-firefox-get-help = Get Help

# link title for https://www.mozilla.org/firefox/customize/
default-bookmarks-firefox-customize = Customize Gorilla Unleashed

# link title for https://www.mozilla.org/contribute/
default-bookmarks-firefox-community = Get Involved

# link title for https://www.mozilla.org/about/
default-bookmarks-firefox-about = About Us

# Firefox Nightly links folder name
default-bookmarks-nightly-heading = Gorilla Unleashed Nightly Resources

# Nightly builds only, link title for https://blog.nightly.mozilla.org/
default-bookmarks-nightly-blog = Gorilla Unleashed Nightly blog

# Nightly builds only, link title for https://bugzilla.mozilla.org/
default-bookmarks-bugzilla = Gorilla Bug Tracker

# Nightly builds only, link title for https://developer.mozilla.org/
default-bookmarks-mdn = Gorilla Developer Network

# Nightly builds only, link title for https://addons.mozilla.org/firefox/addon/nightly-tester-tools/
default-bookmarks-nightly-tester-tools = Nightly Tester Tools

# Nightly builds only, link title for about:crashes
default-bookmarks-crashes = All your crashes

# Nightly builds only, link title for https://planet.mozilla.org/
default-bookmarks-planet = Planet Gorilla
