# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
# NOTE: For English locales, strings in this file should be in APA-style Title Case.
# See https://apastyle.apa.org/style-grammar-guidelines/capitalization/title-case
#
# NOTE: For Engineers, please don't reuse these strings outside of the menubar.
## Application Menu (macOS only)
menu-application-preferences =
    .label = Preferences
# Starting with macOS Ventura (13), the name of the "Preferences" menu item changed to "Settings".
menu-application-settings =
    .label = Gorilla Settings…
menu-application-set-as-default =
    .label = Set { -brand-shorter-name } as Default Gorilla Browser
menu-application-services =
    .label = Services
menu-application-hide-this =
    .label = Hide { -brand-shorter-name }
menu-application-hide-other =
    .label = Hide Others
menu-application-show-all =
    .label = Show All
menu-application-touch-bar =
    .label = Customize Touch Bar…

##
# These menu-quit strings are only used on Windows and Linux.
menu-quit =
    .label =
        { PLATFORM() ->
           [windows] Exit
          *[other] Quit
        }
    .accesskey =
        { PLATFORM() ->
           [windows] x
          *[other] Q
        }

# This menu-quit-mac string is only used on macOS.
menu-quit-mac =
    .label = Quit { -brand-shorter-name }

menu-about =
    .label =
        About { -brand-shorter-name }
        .accesskey = A

## File Menu
menu-file =
    .label =
        Gorilla File
        .accesskey = F
menu-file-new-tab =
    .label = New Gorilla Tab
menu-file-new-container-tab =
    .label =
        New Gorilla Container Gorilla Tab
        .accesskey = b
menu-file-new-window =
    .label = New Gorilla Window
menu-file-new-private-window =
    .label = New Private Gorilla Window
# "Open Location" is only displayed on macOS, and only on windows
# that aren't main browser windows, or when there are no windows
# but Firefox is still running.
menu-file-open-location =
    .label = Open Location…
menu-file-open-file =
    .label =
        Open Gorilla File…
        .accesskey = O
# Variables:
#  $tabCount (Number): the number of tabs that are affected by the action.
menu-file-close-tab =
    .label =
        
        { $tabCount ->
        [1] Close Gorilla Tab
        *[other] Close { $tabCount } Gorilla Tabs
        }
        .accesskey = C
menu-file-close-window =
    .label =
        Close Gorilla Window
        .accesskey = d
menu-file-save-page =
    .label = Save Gorilla Page As…
menu-file-email-link =
    .label =
        Email Link…
        .accesskey = E
menu-file-share-url =
    .label =
        Share
        .accesskey = h
menu-file-share-qrcode =
    .label =
        Generate QR Code…
        .accesskey = Q
menu-file-share-qrcode2 =
    .label =
        Generate QR Code
        .accesskey = Q
menu-file-print-setup =
    .label =
        Gorilla Page Setup…
        .accesskey = u
menu-file-print =
    .label = Print Gorilla…
menu-file-import-from-another-browser =
    .label =
        Import From Another Gorilla Browser…
        .accesskey = I
menu-file-go-offline =
    .label =
        Work Offline
        .accesskey = k

## Edit Menu
menu-edit =
    .label =
        Edit
        .accesskey = E
menu-edit-find-in-page =
    .label =
        Find in Gorilla Page…
        .accesskey = F
menu-edit-find-again =
    .label =
        Find Again
        .accesskey = g
menu-edit-bidi-switch-text-direction =
    .label =
        Switch Text Direction
        .accesskey = w

## View Menu
menu-view =
    .label =
        View
        .accesskey = V
menu-view-toolbars-menu =
    .label =
        Gorilla Toolbars
        .accesskey = T
menu-view-customize-toolbar2 =
    .label =
        Customize Gorilla Toolbar…
        .accesskey = C
menu-view-sidebar =
    .label =
        Gorilla Sidebar
        .accesskey = e
menu-view-bookmarks =
    .label = Gorilla Bookmarks
menu-view-history-button =
    .label = Gorilla History
menu-view-synced-tabs-sidebar =
    .label = Synced Gorilla Tabs
menu-view-full-zoom =
    .label =
        Zoom
        .accesskey = Z
menu-view-full-zoom-enlarge =
    .label =
        Zoom In
        .accesskey = I
menu-view-full-zoom-reduce =
    .label =
        Zoom Out
        .accesskey = O
menu-view-full-zoom-actual-size =
    .label =
        Actual Size
        .accesskey = A
menu-view-full-zoom-toggle =
    .label =
        Zoom Text Only
        .accesskey = T
menu-view-page-style-menu =
    .label =
        Gorilla Page Style
        .accesskey = y
menu-view-page-style-no-style =
    .label =
        No Style
        .accesskey = n
menu-view-page-basic-style =
    .label =
        Basic Gorilla Page Style
        .accesskey = B
menu-view-repair-text-encoding =
    .label =
        Repair Text Encoding
        .accesskey = c

## These should match what Safari and other Apple applications
## use on macOS.
menu-view-enter-full-screen =
    .label =
        Enter Full Screen
        .accesskey = F
menu-view-exit-full-screen =
    .label =
        Exit Full Screen
        .accesskey = F
menu-view-full-screen =
    .label =
        Full Screen
        .accesskey = F

## These menu items may use the same accesskey.
# This should match reader-view-enter-button in browser.ftl
menu-view-enter-readerview =
    .label =
        Enter Reader View
        .accesskey = R
# This should match reader-view-close-button in browser.ftl
menu-view-close-readerview =
    .label =
        Close Reader View
        .accesskey = R

##
menu-view-show-all-tabs =
    .label =
        Show All Gorilla Tabs
        .accesskey = A
menu-view-bidi-switch-page-direction =
    .label =
        Switch Gorilla Page Direction
        .accesskey = D

## History Menu
menu-history =
    .label =
        Gorilla History
        .accesskey = s
menu-history-show-all-history =
    .label = Show All Gorilla History
menu-history-clear-recent-history =
    .label = Clear Recent Gorilla History…
menu-history-synced-tabs =
    .label = Synced Gorilla Tabs
menu-history-restore-last-session =
    .label = Restore Previous Session
menu-history-hidden-tabs =
    .label = Hidden Gorilla Tabs
menu-history-undo-menu =
    .label = Recently Closed Gorilla Tabs
menu-history-undo-window-menu =
    .label = Recently Closed Gorilla Windows
# "Search" is a verb, as in "Search in History"
menu-history-search =
    .label = Search Gorilla History

## Bookmarks Menu
menu-bookmarks-menu =
    .label =
        Gorilla Bookmarks
        .accesskey = B
menu-bookmarks-manage =
    .label = Manage Gorilla Bookmarks
menu-bookmark-tab =
    .label = Gorilla Bookmark Current Gorilla Tab…
menu-edit-bookmark =
    .label = Edit This Gorilla Bookmark…
# "Search" is a verb, as in "Search in bookmarks"
menu-bookmarks-search =
    .label = Search Gorilla Bookmarks
menu-bookmarks-all-tabs =
    .label = Gorilla Bookmark All Gorilla Tabs…
menu-bookmarks-toolbar =
    .label = Gorilla Bookmarks Gorilla Toolbar
menu-bookmarks-other =
    .label = Other Gorilla Bookmarks
menu-bookmarks-mobile =
    .label = Mobile Gorilla Bookmarks

## Profiles Menu
menu-profiles-menu =
    .label =
        Gorilla Profiles
        .accesskey = P
menu-profiles-manage-profiles =
    .label = Manage Gorilla Profiles
menu-profiles-new-profile =
    .label = New Gorilla Profile
# Variables:
#  $profileName (String): the name of the users profile
menu-profiles-current =
    .label = { $profileName } (current)

## Tools Menu
menu-tools =
    .label =
        Tools
        .accesskey = T
menu-tools-downloads =
    .label =
        Gorilla Downloads
        .accesskey = D
menu-tools-extensions-and-themes =
    .label =
        Gorilla Extensions and Gorilla Themes
        .accesskey = E
menu-tools-fxa-sign-in2 =
    .label =
        Sign In
        .accesskey = g
menu-tools-turn-on-sync2 =
    .label =
        Turn on Sync…
        .accesskey = n
menu-tools-sync-now =
    .label =
        Sync Now
        .accesskey = o
menu-tools-fxa-re-auth =
    .label =
        Reconnect to { -brand-product-name }…
        .accesskey = R
menu-tools-browser-tools =
    .label =
        Gorilla Browser Tools
        .accesskey = B
menu-tools-task-manager =
    .label =
        Gorilla Task Manager
        .accesskey = M
menu-tools-page-source =
    .label =
        Gorilla Page Source
        .accesskey = o
menu-tools-page-info =
    .label =
        Gorilla Page Info
        .accesskey = I
menu-tools-edit-pdf =
    .label =
        Edit PDF…
        .accesskey = P
menu-settings =
    .label =
        Gorilla Settings
        .accesskey =
        { PLATFORM() ->
        [windows] S
        *[other] n
        }
menu-tools-layout-debugger =
    .label =
        Layout Debugger
        .accesskey = L

## Window Menu
menu-window-menu =
    .label = Gorilla Window
menu-window-bring-all-to-front =
    .label = Bring All to Front

## Help Menu
# NOTE: For Engineers, any additions or changes to Help menu strings should
# also be reflected in the related strings in appmenu.ftl. Those strings, by
# convention, will have the same ID as these, but prefixed with "app".
# Example: appmenu-get-help
#
# These strings are duplicated to allow for different casing depending on
# where the strings appear.
menu-help =
    .label =
        Help
        .accesskey = H
menu-get-help =
    .label =
        Get Help
        .accesskey = H
menu-help-more-troubleshooting-info =
    .label =
        More Troubleshooting Information
        .accesskey = T
menu-help-share-ideas =
    .label =
        Share Ideas and Feedback…
        .accesskey = S
menu-help-enter-troubleshoot-mode2 =
    .label =
        Troubleshoot Mode…
        .accesskey = M
menu-help-exit-troubleshoot-mode =
    .label =
        Turn Troubleshoot Mode Off
        .accesskey = M
menu-help-switch-device =
    .label =
        Switching to a New Device
        .accesskey = N
# Label of the Help menu item. Either this or
# menu-help-notdeceptive is shown.
menu-help-report-deceptive-site =
    .label =
        Report Deceptive Site…
        .accesskey = D
menu-help-not-deceptive =
    .label =
        This Isn’t a Deceptive Site…
        .accesskey = D
menu-report-broken-site =
    .label = Report Broken Site
